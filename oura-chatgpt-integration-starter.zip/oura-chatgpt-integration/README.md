# Oura ChatGPT Integration

Starter application for an Oura OAuth/API integration intended to be exposed to ChatGPT through a future plugin/MCP-compatible interface.

## Production URLs

- Website: https://oura-chatgpt-integration.vercel.app
- Privacy: https://oura-chatgpt-integration.vercel.app/privacy
- Terms: https://oura-chatgpt-integration.vercel.app/terms
- OAuth callback: https://oura-chatgpt-integration.vercel.app/oauth/callback

## Environment variables

Set these in Vercel. Never commit real values to GitHub.

- `OURA_CLIENT_ID`
- `OURA_CLIENT_SECRET`
- `OURA_REDIRECT_URI`

## Current Oura OAuth flow

Oura API V2 uses OAuth 2.0 authorization-code flow.

Authorize:
`https://cloud.ouraring.com/oauth/authorize`

Token exchange:
`https://api.ouraring.com/oauth/token`

The starter app requests:
`email personal daily heartrate workout tag session spo2Daily`

A user can decline individual scopes during authorization.

## Security notes

This starter does **not** persist Oura access or refresh tokens. The callback exchanges the authorization code only to verify the OAuth flow, then shows a success page without exposing token values. Persistent token storage should be added only after choosing a secure server-side datastore and defining the final ChatGPT integration architecture.

The OAuth state parameter is stored in a short-lived secure HttpOnly cookie to mitigate CSRF.
